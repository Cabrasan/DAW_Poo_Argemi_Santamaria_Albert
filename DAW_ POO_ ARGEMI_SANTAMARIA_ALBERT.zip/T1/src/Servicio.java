public class Servicio extends Persona {
    private String seccio;

    public Servicio(String nom, String cognoms, int identificacio, String estat_civil, String data_incorporacio) {
        super(nom, cognoms, identificacio, estat_civil, data_incorporacio);
    }


    public String getSeccio() {
        return seccio;
    }

    public void setSeccio(String seccio) {
        this.seccio = seccio;
    }
}


