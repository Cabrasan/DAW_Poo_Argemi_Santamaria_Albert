public class Persona {

    private String nom;
    private String cognoms;
    private int identificacio;
    private String estat_civil;
    private String data_incorporacio;


    public Persona(String nom, String cognoms, int identificacio, String estat_civil, String data_incorporacio) {
        this.nom = nom;
        this.cognoms = cognoms;
        this.identificacio = identificacio;
        this.estat_civil = estat_civil;
        this.data_incorporacio = data_incorporacio;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCognoms() {
        return cognoms;
    }

    public void setCognoms(String cognoms) {
        this.cognoms = cognoms;
    }

    public int getIdentificacio() {
        return identificacio;
    }

    public void setIdentificacio(int identificacio) {
        this.identificacio = identificacio;
    }

    public String getEstat_civil() {
        return estat_civil;
    }

    public void setEstat_civil(String estat_civil) {
        this.estat_civil = estat_civil;
    }

    public String getData_incorporacio() {
        return data_incorporacio;
    }

    public void setData_incorporacio(String data_incorporacio) {
        this.data_incorporacio = data_incorporacio;
    }
}
