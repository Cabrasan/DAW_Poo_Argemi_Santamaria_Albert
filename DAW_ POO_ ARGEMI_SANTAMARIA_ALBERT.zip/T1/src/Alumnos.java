public class Alumnos extends Persona{

    private String curs;

    public Alumnos(String nom, String cognoms, int identificacio, String estat_civil, String data_incorporacio) {
        super(nom, cognoms, identificacio, estat_civil, data_incorporacio);
    }


    public String getCurs() {
        return curs;
    }

    public void setCurs(String curs) {
        this.curs = curs;
    }
}
