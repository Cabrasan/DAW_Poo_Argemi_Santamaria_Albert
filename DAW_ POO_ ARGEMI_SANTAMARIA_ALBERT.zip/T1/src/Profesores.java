public class Profesores extends Persona {

    private String departament;

    public Profesores(String nom, String cognoms, int identificacio, String estat_civil, String data_incorporacio) {
        super(nom, cognoms, identificacio, estat_civil, data_incorporacio);
    }


    public String getDepartament() {
        return departament;
    }

    public void setDepartament(String departament) {
        this.departament = departament;
    }
}
