
public class Main {

    public static void main(String[] args) {
    Alumnos alumno = new Alumnos("jose", "nogales", 2, "casat", "20/01/1999");
        System.out.println(alumno.getNom());
        System.out.println(alumno.getCognoms());
        System.out.println(alumno.getIdentificacio());
        System.out.println(alumno.getEstat_civil());
        System.out.println(alumno.getData_incorporacio());
        System.out.println(alumno.getCurs());

        Profesores profe = new Profesores("Manel", "Taboada", 123, "casat", "20/01/1945");
        System.out.println(profe.getNom());
        System.out.println(profe.getCognoms());
        System.out.println(profe.getIdentificacio());
        System.out.println(profe.getEstat_civil());
        System.out.println(profe.getData_incorporacio());

        Servicio serv = new Servicio("Pakita", "Pinga",69, "Soltera", "12/02/1238");

        Persona pers = new Persona("", "", 1, "", "");
        pers.setEstat_civil("Casat");
        System.out.println(pers.getEstat_civil());

        profe.setIdentificacio(12);
        System.out.println(profe.getIdentificacio());

        alumno.setCurs("Segundo");
        System.out.println(alumno.getCurs());

        profe.setDepartament("9");
        System.out.println(profe.getDepartament());

        serv.setSeccio("Limpieza");
        System.out.println(serv.getSeccio());

        

    }


}
